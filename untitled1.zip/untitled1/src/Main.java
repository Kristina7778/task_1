
import java.util.Arrays;


public class Main {

    //#1
    public static int remainder(int a, int b) {
        return a % b;
    }

    //#2
    public static double triArea(int s, int h) {
        return 0.5 * s * h;
    }

    //#3
    public static int animals(int chicken, int cows, int pigs) {
        return 2 * chicken + 4 * (cows + pigs);
    }

    //#4
    public static boolean profitableGamble(int prob, int prize, int pay) {
        return prob * prize > pay;
    }

    //#5
    public static String operation(int n, int a, int b) {
        if (a + b == n)
            return "added";
        else if (a - b == n)
            return "substracted";
        else if (a * b == n)
            return "multiplied";
        else if (a / b == n)
            return "divided";
        else return "none";
    }

    //#6
    public static int ctoa(char a) {
        return  a;
    }

    //#7
    public static int addUpTo(int n) {
        return (n) * (n + 1) / 2;
    }

    //#8
    public static int nextEdge(int a, int b) {
        return a + b - 1;
    }

//    //#9
        public static long sumOfCubes(int[] arr) {
         return Arrays.stream(arr).map(i -> i * i * i).sum();
         }

    //#10
    public static boolean abcmath(int a, int b, int c) {
        long res = (long) (a * Math.pow(2, b));
        return res % c == 0;
    }

    public static void main(String[] args) {

        System.out.println(remainder(1,3));

        System.out.println(triArea(3,2));

        System.out.println(animals(2,3,5));

        System.out.println(profitableGamble(3,50,9));

        System.out.println(operation(24, 15, 9));

        System.out.println(ctoa('A'));
        System.out.println(addUpTo(3));
        System.out.println(nextEdge(8,10));
        int arr[]={1,5,9};
        System.out.println(sumOfCubes(arr));

        System.out.println(abcmath(42, 5, 10)); }}